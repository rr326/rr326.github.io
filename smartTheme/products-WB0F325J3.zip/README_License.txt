(1) All parts, but not limited to the CSS code, images, HTML and design are
licensed according to the license purchased from Wrapbootstrap.

(2) Third party scripts, codes and images maintain their respective licenses.

Read more about licensing here: https://wrapbootstrap.com/help/licenses
